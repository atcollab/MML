function display(schobj,varagrin)
disp(struct(schobj))