function S = step(SCHOBJ);
S = SCHOBJ;
S.CurrentPos = S.CurrentPos+1;