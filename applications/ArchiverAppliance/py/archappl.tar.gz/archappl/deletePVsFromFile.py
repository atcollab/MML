__author__ = 'rfgunion'

from ArchClient import ArchClient

if __name__=='__main__':
	import argparse
	parser = argparse.ArgumentParser(description='delete pvs listed in a file, one per line')
	parser.add_argument('file', help='File(s) from which to read pv names, one per line', type=file, nargs='+')

	args = parser.parse_args()

	client = ArchClient()

	for f in args.file:
		for pvname in f:
			if pvname.startswith('#'):
				continue
			# If pvs get in archiver accidentally with spaces leading or trailing,
			# we will want to remove them.
			#pvname = pvname.strip()
			pvname = pvname[0:-1]
			if pvname == '':
				continue
			print 'Pausing pv "%s"' % pvname
			print client.pauseArchivingPV(pvname)
			print 'Deleting pv "%s"' % pvname
			print client.deletePV(pvname)
